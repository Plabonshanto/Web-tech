<!DOCTYPE html>
<html>
<head>
    <title>Welcome to My Company</title>
</head>
<body>
    <h1>Welcome to My Company</h1>
    <nav>
        <a href="home.php">Home</a> |
        <a href="login.php">Login</a> |
        <a href="registration.php">Registration</a>
    </nav>
</body>
</html>
